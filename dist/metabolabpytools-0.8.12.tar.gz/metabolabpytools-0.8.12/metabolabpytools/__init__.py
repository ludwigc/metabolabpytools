__author__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__credits__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__version__ = '0.8.12'
__license__ = 'GPLv3'

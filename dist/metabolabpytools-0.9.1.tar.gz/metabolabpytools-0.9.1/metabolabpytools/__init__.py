__author__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__credits__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__version__ = '0.9.1'
__license__ = 'GPLv3'
